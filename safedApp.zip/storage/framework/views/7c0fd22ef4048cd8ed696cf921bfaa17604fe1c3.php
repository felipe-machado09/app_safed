<?php $__env->startComponent('mail::message'); ?>
    <h2>Olá <?php echo e($user->name); ?>,</h2>
    <h3>Clique no botão abaixo para realizar o download do relatório solicitado.</h3>
    <?php $__env->startComponent('mail::button', [
    'url' =>  'http://localhost:8000/download/file/'.$file->name.'?token=106c0939-9d67-4928-a909-27fdbf4d65be'
    ]); ?>
    Download
    <?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    Este download ficará disponivel por 3 dias após isto ele sera apagado do servidor!
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\Felipe Machado\Desktop\PROJETOS\safedApp\resources\views/emails/index.blade.php ENDPATH**/ ?>